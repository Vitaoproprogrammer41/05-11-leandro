﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vendas.Models;

namespace Vendas.Controllers
{
    public class DepartmentsController : Controller
    {
        public IActionResult Index()
        {
            List<department> list = new List<department>();
            list.Add(new department { Id = 1, Name = "Eletronicos" });
            list.Add(new department { Id = 2, Name = "Moda" });

            return View(list);
        }
    }
}
