﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vendas.Models;
using Vendas.Services;

namespace Vendas.Controllers
{
    public class sellersController : Controller
    {
        private readonly SellerService _sellerService;

        public sellersController(SellerService sellerService)

        {
            _sellerService = sellerService;
        }

        public IActionResult Index()
        {
            var list = _sellerService.FindAll();
            return View(list);
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
